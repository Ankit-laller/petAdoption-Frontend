/* tslint:disable:no-unused-variable */

import { TestBed, async } from '@angular/core/testing';
import { ImageurlSanitizerPipe } from './imageurl-sanitizer.pipe';

describe('Pipe: ImageurlSanitizere', () => {
  it('create an instance', () => {
    let pipe = new ImageurlSanitizerPipe();
    expect(pipe).toBeTruthy();
  });
});
